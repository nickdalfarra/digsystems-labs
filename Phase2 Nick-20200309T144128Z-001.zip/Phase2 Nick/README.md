# digsystems-labs
Building a RIS Computer for ELEC 374 labs. Everything is built using Verilog HDL.
